from django.apps import AppConfig


class ResumesiteConfig(AppConfig):
    name = 'resumesite'
